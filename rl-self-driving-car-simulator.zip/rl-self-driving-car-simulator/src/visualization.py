import matplotlib.pyplot as plt
import matplotlib.animation as animation
from collections import deque
import numpy as np
import threading
import time

class TrainingVisualizer:
    def __init__(self, max_points=1000):
        self.max_points = max_points
        
        # Data storage
        self.episodes = deque(maxlen=max_points)
        self.rewards = deque(maxlen=max_points)
        self.steps = deque(maxlen=max_points)
        self.losses = deque(maxlen=max_points)
        
        # Create figure with subplots
        self.fig, (self.ax1, self.ax2) = plt.subplots(2, 1, figsize=(12, 8))
        self.fig.suptitle('Self-Driving Car RL Training Metrics', fontsize=16)
        
        # Reward vs Episode plot
        self.reward_line, = self.ax1.plot([], [], 'b-', linewidth=2, label='Episode Reward')
        self.ax1.set_xlabel('Episode')
        self.ax1.set_ylabel('Total Reward')
        self.ax1.set_title('Reward vs Episode')
        self.ax1.grid(True, alpha=0.3)
        self.ax1.legend()
        
        # Loss vs Step plot
        self.loss_line, = self.ax2.plot([], [], 'r-', linewidth=2, label='Training Loss')
        self.ax2.set_xlabel('Training Step')
        self.ax2.set_ylabel('Loss')
        self.ax2.set_title('Loss vs Training Step')
        self.ax2.grid(True, alpha=0.3)
        self.ax2.legend()
        
        # Animation
        self.ani = None
        self.running = False
        
    def add_reward(self, episode, reward):
        """Add new reward data point"""
        self.episodes.append(episode)
        self.rewards.append(reward)
        
    def add_loss(self, step, loss):
        """Add new loss data point"""
        self.steps.append(step)
        self.losses.append(loss)
        
    def update_plots(self, frame):
        """Update plot data"""
        if len(self.episodes) > 0:
            self.reward_line.set_data(list(self.episodes), list(self.rewards))
            self.ax1.relim()
            self.ax1.autoscale_view()
            
        if len(self.steps) > 0:
            self.loss_line.set_data(list(self.steps), list(self.losses))
            self.ax2.relim()
            self.ax2.autoscale_view()
            
        return self.reward_line, self.loss_line
    
    def start_animation(self):
        """Start the animation"""
        self.running = True
        self.ani = animation.FuncAnimation(
            self.fig, 
            self.update_plots, 
            interval=1000,  # Update every second
            blit=True,
            cache_frame_data=False
        )   
        
    def stop_animation(self):
        """Stop the animation"""
        if self.running:
            self.running = False
            if self.ani:
                self.ani.event_source.stop()
            plt.close(self.fig)
        
    def save_plots(self, filename_prefix='training_metrics'):
        """Save plots to files"""
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        
        # Save combined plot
        self.fig.savefig(f'{filename_prefix}_{timestamp}.png', dpi=300, bbox_inches='tight')
        
        # Save individual plots
        fig1, ax1 = plt.subplots(figsize=(10, 6))
        ax1.plot(list(self.episodes), list(self.rewards), 'b-', linewidth=2)
        ax1.set_xlabel('Episode')
        ax1.set_ylabel('Total Reward')
        ax1.set_title('Reward vs Episode')
        ax1.grid(True, alpha=0.3)
        fig1.savefig(f'{filename_prefix}_reward_{timestamp}.png', dpi=300, bbox_inches='tight')
        plt.close(fig1)
        
        fig2, ax2 = plt.subplots(figsize=(10, 6))
        ax2.plot(list(self.steps), list(self.losses), 'r-', linewidth=2)
        ax2.set_xlabel('Training Step')
        ax2.set_ylabel('Loss')
        ax2.set_title('Loss vs Training Step')
        ax2.grid(True, alpha=0.3)
        fig2.savefig(f'{filename_prefix}_loss_{timestamp}.png', dpi=300, bbox_inches='tight')
        plt.close(fig2)

class SimpleVisualizer:
    """Simplified visualizer for playback mode"""
    def __init__(self):
        self.fig = None
        
    def show_training_complete(self, episode_rewards, training_losses):
        """Display training completion graphs"""
        fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 8))
        fig.suptitle('Training Results Summary', fontsize=16)
        
        # Reward vs Episode
        if episode_rewards:
            episodes = range(1, len(episode_rewards) + 1)
            ax1.plot(episodes, episode_rewards, 'b-', linewidth=2)
            ax1.set_xlabel('Episode')
            ax1.set_ylabel('Total Reward')
            ax1.set_title('Reward vs Episode')
            ax1.grid(True, alpha=0.3)
            
            # Add trend line
            if len(episodes) > 1:
                z = np.polyfit(episodes, episode_rewards, 1)
                p = np.poly1d(z)
                ax1.plot(episodes, p(episodes), "r--", alpha=0.8, label=f'Trend: {z[0]:.2f}x + {z[1]:.2f}')
                ax1.legend()
        
        # Loss vs Step
        if training_losses:
            steps = range(1, len(training_losses) + 1)
            ax2.plot(steps, training_losses, 'r-', linewidth=2)
            ax2.set_xlabel('Training Step')
            ax2.set_ylabel('Loss')
            ax2.set_title('Loss vs Training Step')
            ax2.grid(True, alpha=0.3)
            
            # Add moving average
            if len(steps) > 10:
                window_size = min(50, len(steps) // 10)
                moving_avg = np.convolve(training_losses, np.ones(window_size)/window_size, mode='valid')
                ax2.plot(steps[window_size-1:], moving_avg, 'g-', alpha=0.8, label=f'Moving Avg ({window_size})')
                ax2.legend()
        
        plt.tight_layout()
        plt.show()
