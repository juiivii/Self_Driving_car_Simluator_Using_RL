import pygame

class Track:
    def __init__(self, screen_width, screen_height):
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.track_color = (50, 50, 50)
        self.boundary_color = (255, 255, 255)
        self.boundary_thickness = 10

        # Define the rectangular track boundaries (inner and outer rectangles)
        margin = 50
        self.outer_rect = pygame.Rect(margin, margin, screen_width - 2 * margin, screen_height - 2 * margin)
        self.inner_rect = pygame.Rect(margin + 100, margin + 100, screen_width - 2 * (margin + 100), screen_height - 2 * (margin + 100))

        # Define obstacles as list of pygame.Rect
        self.obstacles = [
            pygame.Rect(screen_width // 2 - 50, screen_height // 2 - 100, 40, 40),
            pygame.Rect(screen_width // 2 + 100, screen_height // 2, 60, 60),
            pygame.Rect(screen_width // 2 - 150, screen_height // 2 + 50, 50, 50)
        ]

    def draw(self, screen):
        # Draw outer boundary with gradient effect
        for i in range(self.boundary_thickness):
            color_value = 255 - i * 10
            color = (color_value, color_value, color_value)
            pygame.draw.rect(screen, color, self.outer_rect.inflate(-i*2, -i*2), 1)
        # Draw inner boundary with gradient effect
        for i in range(self.boundary_thickness):
            color_value = 255 - i * 10
            color = (color_value, color_value, color_value)
            pygame.draw.rect(screen, color, self.inner_rect.inflate(-i*2, -i*2), 1)
        # Fill the road area between outer and inner rectangles with texture pattern
        road_rect = self.outer_rect.inflate(-self.boundary_thickness*2, -self.boundary_thickness*2)
        # Draw a simple pattern for road
        tile_size = 20
        for x in range(road_rect.left, road_rect.right, tile_size):
            for y in range(road_rect.top, road_rect.bottom, tile_size):
                rect = pygame.Rect(x, y, tile_size, tile_size)
                color = (60, 60, 60) if (x//tile_size + y//tile_size) % 2 == 0 else (50, 50, 50)
                pygame.draw.rect(screen, color, rect)
        # Draw obstacles with texture
        for obstacle in self.obstacles:
            pygame.draw.rect(screen, (150, 0, 0), obstacle)  # Dark red base
            inner_rect = obstacle.inflate(-4, -4)
            pygame.draw.rect(screen, (200, 0, 0), inner_rect)  # Bright red inner
