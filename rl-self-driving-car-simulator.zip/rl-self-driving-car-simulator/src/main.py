import pygame
import sys
import argparse
import threading
import time
from car import Car
from road import Road
from rl_agent import CarEnv
from visualization import TrainingVisualizer, SimpleVisualizer
from stable_baselines3 import DQN
import os
import numpy as np
import matplotlib.pyplot as plt

def train_with_visualization(total_timesteps=10000, save_model=True):
    """Train the RL agent with real-time visualization"""
    print("Starting training with visualization...")

    env = CarEnv()
    visualizer = TrainingVisualizer()

    model = DQN('MlpPolicy', env, verbose=1)

    episode_rewards = []
    training_losses = []
    current_episode = 0
    episode_reward = 0

    obs = env.reset()

    plt.ion()

    try:
        for step in range(total_timesteps):
            action, _states = model.predict(obs, deterministic=False)
            obs, reward, done, info = env.step(action)

            episode_reward += reward

            if step % 10 == 0:
                training_losses.append(-reward)
                visualizer.add_loss(step, -reward)

            if done:
                current_episode += 1
                episode_rewards.append(episode_reward)
                visualizer.add_reward(current_episode, episode_reward)

                print(f"Episode {current_episode}: Reward = {episode_reward:.2f}")

                episode_reward = 0
                obs = env.reset()

            if step % 10 == 0:
                env.render()
                visualizer.update_plots(step)
                plt.pause(0.001)

        if save_model:
            model.save("dqn_car_model")
            print("Model saved as dqn_car_model.zip")

        visualizer.save_plots('training_results')
        print("Training plots saved")

    finally:
        plt.ioff()
        plt.close(visualizer.fig)
        env.close()

    return episode_rewards, training_losses

def playback_with_results(model_path="dqn_car_model.zip", episodes=5):
    """Playback trained model and show results summary"""
    print(f"Loading model from {model_path}...")
    
    if not os.path.exists(model_path):
        print(f"Model file {model_path} not found!")
        return
    
    # Initialize environment
    env = CarEnv()
    model = DQN.load(model_path)
    
    episode_rewards = []
    
    print(f"Running {episodes} episodes...")
    
    for episode in range(episodes):
        obs = env.reset()
        done = False
        episode_reward = 0
        
        while not done:
            action, _states = model.predict(obs, deterministic=True)
            obs, reward, done, info = env.step(action)
            episode_reward += reward
            
            env.render()
        
        episode_rewards.append(episode_reward)
        print(f"Episode {episode + 1}: Reward = {episode_reward:.2f}")
    
    env.close()
    
    # Show results summary
    if episode_rewards:
        simple_viz = SimpleVisualizer()
        simple_viz.show_training_complete(episode_rewards, [])
        print("Results summary displayed")

def simple_playback():
    """Simple playback mode with live visualization"""
    import threading
    import matplotlib.pyplot as plt
    
    pygame.init()
    screen_width, screen_height = 800, 600
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("2D Self-Driving Car Game with Live Visualization")

    clock = pygame.time.Clock()

    env = CarEnv(screen_width, screen_height)
    env.reset()

    # Load trained model for playback
    model_path = "dqn_car_model.zip"
    if os.path.exists(model_path):
        model = DQN.load(model_path)
        env.model = model
    else:
        print("No trained model found. Please train a model first.")
        env.model = None
        return

    # Initialize live visualizer
    from visualization import TrainingVisualizer
    visualizer = TrainingVisualizer()
    
    # Data tracking for live visualization
    episode_rewards = []
    current_episode = 0
    episode_reward = 0
    step_count = 0
    
    # Start visualization in a separate thread
    def run_visualizer():
        visualizer.start_animation()
    
    viz_thread = threading.Thread(target=run_visualizer)
    viz_thread.daemon = True
    viz_thread.start()

    font = pygame.font.SysFont(None, 24)
    score = 0
    running = True
    
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        # Use RL agent to decide action
        obs = env._get_obs()
        action, _states = env.model.predict(obs, deterministic=True) if env.model else (0, None)

        obs, reward, done, info = env.step(action)
        score += reward
        episode_reward += reward
        
        # Update visualization data
        step_count += 1
        if step_count % 10 == 0:  # Update loss every 10 steps
            visualizer.add_loss(step_count, -reward)  # Negative reward as loss proxy

        env.render()

        # Draw UI
        screen = env.screen
        score_text = font.render(f"Score: {int(score)}", True, (255, 255, 255))
        episode_text = font.render(f"Episode: {current_episode + 1}", True, (255, 255, 255))
        screen.blit(score_text, (10, 10))
        screen.blit(episode_text, (10, 40))

        pygame.display.flip()
        clock.tick(60)

        if done:
            current_episode += 1
            episode_rewards.append(episode_reward)
            visualizer.add_reward(current_episode, episode_reward)
            
            print(f"Episode {current_episode}: Reward = {episode_reward:.2f}")
            
            env.reset()
            score = 0
            episode_reward = 0
            step_count = 0

    # Save final plots
    visualizer.save_plots('simple_playback_results')
    visualizer.stop_animation()
    
    env.close()
    pygame.quit()
    sys.exit()

def main():
    """Main function with command-line interface"""
    parser = argparse.ArgumentParser(description='Self-Driving Car RL Training and Playback')
    parser.add_argument('--mode', choices=['train', 'playback', 'simple'],
                       default='simple', help='Mode to run: train, playback, or simple')
    parser.add_argument('--timesteps', type=int, default=10000,
                       help='Number of timesteps for training (default: 10000)')
    parser.add_argument('--episodes', type=int, default=5,
                       help='Number of episodes for playback (default: 5)')
    parser.add_argument('--model', type=str, default='dqn_car_model.zip',
                       help='Path to trained model file (default: dqn_car_model.zip)')

    args = parser.parse_args()

    if args.mode == 'train':
        print("Starting training mode with visualization...")
        train_with_visualization(args.timesteps)

    elif args.mode == 'playback':
        print("Starting playback mode with results summary...")
        playback_with_results(args.model, args.episodes)

    else:  # simple mode
        print("Starting simple playback mode...")
        simple_playback()

if __name__ == "__main__":
    main()
