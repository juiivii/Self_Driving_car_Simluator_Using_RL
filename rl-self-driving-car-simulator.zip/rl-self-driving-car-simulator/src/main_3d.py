
from stable_baselines3 import DQN
from rl_agent_3d import CarEnv3D

def main():
    # Set headless=False to watch the simulation
    env = CarEnv3D(headless=False)

    # Load the trained model
    try:
        model = DQN.load("dqn_car_model_3d", env=env)
    except Exception as e:
        print(f"Error loading model: {e}")
        print("Please ensure 'dqn_car_model_3d.zip' exists and that you have stable-baselines3 and PyTorch installed.")
        env.close()
        return

    # Endless simulation loop
    while True:
        obs = env.reset()
        done = False
        print("Starting new episode...")
        while not done:
            # The model predicts the best action to take
            action, _states = model.predict(obs, deterministic=True)
            print(f"Action chosen: {action}")
            
            # The environment executes the action
            obs, reward, done, info = env.step(action)
        
        print("Episode finished (car crashed or went off-road). Resetting.")

    # To exit the simulation, you can press Ctrl+C in the terminal.
    # env.close() # This line is now unreachable but kept for reference.

if __name__ == "__main__":
    main()
