import pygame
import random

class Road:
    def __init__(self, screen_width, screen_height):
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.road_width = int(screen_width * 0.8)  # 80% of screen width
        self.road_color = (50, 50, 50)
        self.lane_marker_color = (255, 255, 255)
        self.lane_marker_width = 5
        self.lane_marker_height = 40
        self.lane_marker_gap = 20
        self.lane_marker_speed = 5

        # Position of the road (centered horizontally)
        self.road_x = (screen_width - self.road_width) // 2

        # List of lane markers (y positions)
        self.lane_markers = []
        self._init_lane_markers()

        # Obstacles list: each obstacle is a pygame.Rect
        self.obstacles = []
        self.obstacle_width = 40
        self.obstacle_height = 40
        self.obstacle_color = (200, 0, 0)
        self.obstacle_speed = 7
        self.spawn_timer = 0
        self.spawn_interval = 20  # More frequent obstacles

    def _init_lane_markers(self):
        # Initialize lane markers spaced vertically along the road
        y = 0
        while y < self.screen_height:
            self.lane_markers.append(y)
            y += self.lane_marker_height + self.lane_marker_gap

    def update(self):
        # Move lane markers down to simulate road movement
        for i in range(len(self.lane_markers)):
            self.lane_markers[i] += self.lane_marker_speed
            if self.lane_markers[i] > self.screen_height:
                self.lane_markers[i] = -self.lane_marker_height

        # Update obstacles positions
        for obstacle in self.obstacles:
            obstacle.y += self.obstacle_speed

        # Remove obstacles that moved off screen
        self.obstacles = [obs for obs in self.obstacles if obs.y < self.screen_height]

        # Spawn new obstacles periodically
        self.spawn_timer += 1
        if self.spawn_timer >= self.spawn_interval:
            self.spawn_timer = 0
            self.spawn_obstacle()

    def spawn_obstacle(self):
        # Spawn obstacle at random lane position closer to the car
        lane_positions = [
            self.road_x + self.road_width // 4 - self.obstacle_width // 2,
            self.road_x + self.road_width // 2 - self.obstacle_width // 2,
            self.road_x + 3 * self.road_width // 4 - self.obstacle_width // 2,
        ]
        x = random.choice(lane_positions)
        y = 250 - self.obstacle_height  # Spawn closer to the car at y=300
        new_obstacle = pygame.Rect(x, y, self.obstacle_width, self.obstacle_height)
        self.obstacles.append(new_obstacle)

    def draw(self, screen):
        # Draw road background
        pygame.draw.rect(screen, self.road_color, (self.road_x, 0, self.road_width, self.screen_height))

        # Draw lane markers with pseudo-3D scaling
        lane_center = self.road_x + self.road_width // 2
        for y in self.lane_markers:
            scale_factor = 0.5 + 0.5 * (y / self.screen_height)  # scale between 0.5 and 1.0
            marker_width = int(self.lane_marker_width * scale_factor)
            marker_height = int(self.lane_marker_height * scale_factor)
            pygame.draw.rect(screen, self.lane_marker_color,
                             (lane_center - marker_width // 2, y,
                              marker_width, marker_height))

        # Draw obstacles with pseudo-3D scaling
        for obstacle in self.obstacles:
            scale_factor = 0.5 + 0.5 * (obstacle.y / self.screen_height)  # scale between 0.5 and 1.0
            new_width = int(self.obstacle_width * scale_factor)
            new_height = int(self.obstacle_height * scale_factor)
            scaled_rect = pygame.Rect(
                obstacle.x + (obstacle.width - new_width) // 2,
                obstacle.y,
                new_width,
                new_height
            )
            pygame.draw.rect(screen, self.obstacle_color, scaled_rect)
 