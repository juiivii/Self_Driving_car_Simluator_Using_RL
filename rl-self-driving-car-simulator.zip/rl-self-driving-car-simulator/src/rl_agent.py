import gym
from gym import spaces
import numpy as np
from stable_baselines3 import DQN
from stable_baselines3.common.callbacks import CheckpointCallback
import pygame
from car import Car
from road import Road

class CarEnv(gym.Env):
    metadata = {'render.modes': ['human']}

    def __init__(self, screen_width=800, screen_height=600):
        super(CarEnv, self).__init__()
        self.screen_width = screen_width
        self.screen_height = screen_height

        import random
        # Define lane positions (left, middle, right lanes)
        road = Road(screen_width, screen_height)
        self.lane_positions = [
            road.road_x + road.road_width // 4,
            road.road_x + road.road_width // 2,
            road.road_x + 3 * road.road_width // 4
        ]

        # Define action and observation space
        # Actions: 0 = no action, 1 = accelerate, 2 = turn left, 3 = turn right
        self.action_space = spaces.Discrete(4)

        # Observation space: sensor distances normalized [0,1]
        self.observation_space = spaces.Box(low=0, high=1, shape=(13,), dtype=np.float32)

        # Initialize pygame and simulator components
        pygame.init()
        self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
        pygame.display.set_caption("RL Training Environment")

        self.clock = pygame.time.Clock()
        # Initialize road
        self.road = Road(self.screen_width, self.screen_height)
        # Initialize car in random left or right lane
        self.car = Car(random.choice(self.lane_positions), self.screen_height - 100)
        self.done = False
        self.total_reward = 0
        self.steps = 0
        self.max_steps = 1000

    def reset(self):
        self.car = Car(self.screen_width // 2, self.screen_height - 100)
        self.road = Road(self.screen_width, self.screen_height)
        self.done = False
        self.total_reward = 0
        self.steps = 0
        return self._get_obs()

    def _get_obs(self):
        # Use sensor distances to obstacles and road edges
        track_boundaries = [pygame.Rect(self.road.road_x, 0, 1, self.screen_height),
                            pygame.Rect(self.road.road_x + self.road.road_width, 0, 1, self.screen_height)]
        track_boundaries += self.road.obstacles
        self.car.update_sensors(track_boundaries)
        return np.array(self.car.sensor_distances) / self.car.max_sensor_distance

    def step(self, action):
        obs = self._get_obs()

        # Heuristic override: if any obstacle close in any sensor, take action
        threshold_distance = 150  # increased threshold for earlier obstacle detection
        close_obstacle = any((dist * self.car.max_sensor_distance) < threshold_distance for dist in obs)

        if close_obstacle:
            # Check all sensor distances for lane clearance
            left_lane = self.lane_positions[0]
            right_lane = self.lane_positions[1]
            current_x = self.car.x

            # Calculate sensor distances for each lane more precisely
            left_lane_sensors = [obs[0], obs[1], obs[2]]  # sensors at -90, -75, -60 degrees
            middle_lane_sensors = [obs[3], obs[4], obs[5], obs[6], obs[7], obs[8], obs[9]]  # sensors around 0 degrees
            right_lane_sensors = [obs[10], obs[11], obs[12]]  # sensors at 60, 75, 90 degrees

            left_distance = min([d * self.car.max_sensor_distance for d in left_lane_sensors]) if left_lane_sensors else 0
            middle_distance = min([d * self.car.max_sensor_distance for d in middle_lane_sensors]) if middle_lane_sensors else 0
            right_distance = min([d * self.car.max_sensor_distance for d in right_lane_sensors]) if right_lane_sensors else 0

            # Debug prints for sensor distances and current position
            print(f"Left distance: {left_distance}, Middle distance: {middle_distance}, Right distance: {right_distance}, Current x: {current_x}")

            # Decide lane switch direction based on which lane has most clearance
            lane_clearances = [left_distance, middle_distance, right_distance]

            # Find lane with max clearance
            best_lane_index = lane_clearances.index(max(lane_clearances))

            # Check if obstacles are close on both sides
            left_close = lane_clearances[0] < 100
            right_close = lane_clearances[2] < 100

            # Find current lane index
            lane_index = None
            for i, lane_x in enumerate(self.lane_positions):
                if abs(current_x - lane_x) < 10:
                    lane_index = i
                    break

            print(f"Current lane index: {lane_index}, Best lane index: {best_lane_index}")

            if left_close and right_close:
                # Move car to middle position between left and right lanes
                middle_pos = (self.lane_positions[0] + self.lane_positions[2]) / 2
                self.car.target_x = middle_pos
                action = 0  # no lane switch action needed
            elif lane_index is not None and best_lane_index != lane_index:
                if best_lane_index < lane_index:
                    action = 2  # switch left
                elif best_lane_index > lane_index:
                    action = 3  # switch right
                else:
                    action = 0  # no lane switch
            else:
                action = 0  # no lane switch, decelerate

        # Execute action
        if action == 1:
            self.car.accelerate()
        elif action == 2:
            # Move car one lane to the left if possible
            current_x = self.car.x
            lane_positions = self.lane_positions
            # Find current lane index
            lane_index = None
            for i, lane_x in enumerate(lane_positions):
                if abs(current_x - lane_x) < 10:
                    lane_index = i
                    break
            if lane_index is not None and lane_index > 0:
                new_lane_x = lane_positions[lane_index - 1]
                # Set target lane position for smooth lane switching
                self.car.target_x = new_lane_x
        elif action == 3:
            # Move car one lane to the right if possible
            current_x = self.car.x
            lane_positions = self.lane_positions
            # Find current lane index
            lane_index = None
            for i, lane_x in enumerate(lane_positions):
                if abs(current_x - lane_x) < 10:
                    lane_index = i
                    break
            if lane_index is not None and lane_index < len(lane_positions) - 1:
                new_lane_x = lane_positions[lane_index + 1]
                # Set target lane position for smooth lane switching
                self.car.target_x = new_lane_x
        else:
            self.car.decelerate()

        self.car.update()
        self.road.update()
        self.steps += 1

        reward = self._compute_reward()
        self.total_reward += reward

        self.done = self._check_done()

        return obs, reward, self.done, {}

    def _compute_reward(self):
        reward = 0
        x, y = self.car.x, self.car.y
        # Reward for staying within road boundaries
        if self.road.road_x < x < self.road.road_x + self.road.road_width:
            reward += 1
        else:
            reward -= 10
        # Penalty for hitting obstacles
        for obstacle in self.road.obstacles:
            if obstacle.collidepoint(x, y):
                reward -= 20
        # Reward for speed
        reward += self.car.speed * 0.1
        return reward

    def _check_done(self):
        if self.steps >= self.max_steps:
            return True
        x, y = self.car.x, self.car.y
        if not (self.road.road_x < x < self.road.road_x + self.road.road_width):
            return True
        for obstacle in self.road.obstacles:
            if obstacle.collidepoint(x, y):
                return True
        return False

    def render(self, mode='human'):
        self.screen.fill((0, 0, 0))
        self.road.draw(self.screen)
        self.car.draw(self.screen)
        pygame.display.flip()
        self.clock.tick(60)

    def close(self):
        pygame.quit()

def train_agent():
    env = CarEnv()
    checkpoint_callback = CheckpointCallback(save_freq=1000, save_path='./models/', name_prefix='dqn_car')
    model = DQN('MlpPolicy', env, verbose=1)
    model.learn(total_timesteps=10000, callback=checkpoint_callback)
    model.save("dqn_car_model")

def play_agent():
    env = CarEnv()
    model = DQN.load("dqn_car_model")
    obs = env.reset()
    done = False
    while not done:
        action, _states = model.predict(obs)
        obs, rewards, done, info = env.step(action)
        env.render()
    env.close()

if __name__ == "__main__":
    train_agent()
    # Uncomment below to play trained agent
    # play_agent()
