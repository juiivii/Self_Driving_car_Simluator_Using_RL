import gym
from gym import spaces
import numpy as np
from ursina import *
from car_3d import Car3D
from road_3d import Road3D

class CarEnv3D(gym.Env):
    def __init__(self, headless=True):
        super(CarEnv3D, self).__init__()
        self.headless = headless

        # Initialize Ursina
        if not hasattr(self, 'app'):
            self.app = Ursina(headless=headless)

        # Define action and observation space
        self.action_space = spaces.Discrete(5)  # 0: no action, 1: accelerate, 2: decelerate, 3: switch left, 4: switch right
        self.observation_space = spaces.Box(low=0, high=1, shape=(5,), dtype=np.float32)

        # Create car and road
        self.car = Car3D()
        self.road = Road3D()

        # Define lane positions
        self.lane_positions = [-self.road.road_width / 4, self.road.road_width / 4]

        # Add sky
        self.sky = Sky()

        # Add a directional light for shadows
        if not self.headless:
            self.sun = DirectionalLight()
            self.sun.look_at(Vec3(1, -1, 1)) # Direction of the light
            self.sun.shadow_map_resolution = (2048, 2048) # Higher resolution for better shadows

        self.reset()

    def late_update(self):
        if not self.headless:
            camera.position = lerp(camera.position, self.car.position + Vec3(0, 10, -15), time.dt * 2)
            camera.rotation = lerp(camera.rotation, self.car.rotation + Vec3(25, 0, 0), time.dt * 2)

    def reset(self):
        # Start car in a random lane
        lane = random.choice(self.road.lane_positions)
        self.car.position = (lane, 0.5, 0)
        self.car.target_x = lane
        self.car.rotation = (0, 0, 0)
        self.car.speed = 0

        for obstacle in self.road.obstacles:
            destroy(obstacle)
        self.road.obstacles = []

        return self._get_obs()

    def step(self, action):
        if action == 1:
            self.car.accelerate()
        elif action == 2:
            self.car.decelerate()
        elif action == 3:
            # Switch lane left
            current_x = self.car.x
            lane_index = None
            for i, lane_x in enumerate(self.lane_positions):
                if abs(current_x - lane_x) < 1:
                    lane_index = i
                    break
            if lane_index is not None and lane_index > 0:
                self.car.target_x = self.lane_positions[lane_index - 1]
        elif action == 4:
            # Switch lane right
            current_x = self.car.x
            lane_index = None
            for i, lane_x in enumerate(self.lane_positions):
                if abs(current_x - lane_x) < 1:
                    lane_index = i
                    break
            if lane_index is not None and lane_index < len(self.lane_positions) - 1:
                self.car.target_x = self.lane_positions[lane_index + 1]

        self.car.update()
        self.road.update()

        if hasattr(self, 'late_update'):
            self.late_update()

        # Update Ursina
        self.app.step()

        obs = self._get_obs()
        reward = self._compute_reward()
        done = self._check_done()

        return obs, reward, done, {}

    def _get_obs(self):
        return np.array(self.car.sensor_distances) / self.car.max_sensor_distance

    def _compute_reward(self):
        reward = 0
        # Reward for speed
        reward += self.car.speed * 0.1

        # Penalty for collision
        if self.car.intersects().hit:
            reward -= 10

        # Penalty for going off road
        if not -self.road.road_width / 2 < self.car.x < self.road.road_width / 2:
            reward -= 10
        
        # Reward for staying in a lane
        lane_width = self.road.road_width / 2
        lane_centers = [-lane_width / 2, lane_width / 2]
        car_x = self.car.x
        
        min_dist_to_lane = min(abs(car_x - center) for center in lane_centers)
        
        # The reward is higher when the car is closer to the lane center
        lane_reward = 1 - (min_dist_to_lane / (lane_width / 2))
        reward += lane_reward

        return reward

    def _check_done(self):
        if self.car.intersects().hit:
            return True
        if not -self.road.road_width / 2 < self.car.x < self.road.road_width / 2:
            return True
        return False

    def render(self, mode='human'):
        # Rendering is handled by Ursina's app.step() in the main loop
        pass

    def close(self):
        application.quit()