from ursina import *
import random

class Road3D(Entity):
    def __init__(self):
        super().__init__()

        self.road_width = 40
        # The main road plane. It's static.
        self.road = Entity(model='plane', scale=(self.road_width, 1, 2000), color=color.dark_gray, texture='white_cube', texture_scale=(self.road_width, 200), shadows=True)

        # Create and store lane markings to make them movable
        self.lane_markings = []
        self.road_length = 2000 # Total length covered by markings
        for i in range(100):
            z_pos = -500 + i * 20
            # Left lane center
            self.lane_markings.append(Entity(model='quad', scale=(0.5, 1, 10), position=(-self.road_width/4, 0.01, z_pos), color=color.white, parent=self))
            # Right lane center
            self.lane_markings.append(Entity(model='quad', scale=(0.5, 1, 10), position=(self.road_width/4, 0.01, z_pos), color=color.white, parent=self))
            # Center line
            self.lane_markings.append(Entity(model='quad', scale=(0.5, 1, 10), position=(0, 0.01, z_pos), color=color.yellow, parent=self))
            # Left edge
            self.lane_markings.append(Entity(model='quad', scale=(0.5, 1, 10), position=(-self.road_width/2, 0.01, z_pos), color=color.white, parent=self))
            # Right edge
            self.lane_markings.append(Entity(model='quad', scale=(0.5, 1, 10), position=(self.road_width/2, 0.01, z_pos), color=color.white, parent=self))

        self.obstacles = []
        self.spawn_timer = 0
        self.spawn_interval = 1.0

        self.lane_positions = [-self.road_width / 4, self.road_width / 4]

    def update(self, car_speed=10, car_z=0):
        # Move and recycle lane markings to create illusion of movement
        for mark in self.lane_markings:
            mark.z -= car_speed * time.dt
            if mark.z < -550: # When a marking goes far behind the car
                mark.z += self.road_length # Move it to the front

        # Move obstacles
        for obstacle in self.obstacles:
            obstacle.z -= car_speed * time.dt
        
        # Remove obstacles that are behind the car
        self.obstacles = [obs for obs in self.obstacles if obs.z > -50]
        
        # Spawn new obstacles
        self.spawn_timer += time.dt
        if self.spawn_timer >= self.spawn_interval:
            self.spawn_timer = 0
            self.spawn_obstacle(car_z)

    def spawn_obstacle(self, car_z=0):
        lane = random.choice(self.lane_positions)
        x = lane
        z = car_z + 70

        scale_x = random.uniform(2, 4)
        scale_y = random.uniform(2, 4)
        scale_z = random.uniform(2, 4)

        obstacle = Entity(model='cube', color=color.red, scale=(scale_x, scale_y, scale_z), position=(x, scale_y/2, z), collider='box', shadows=True, parent=self)
        self.obstacles.append(obstacle)