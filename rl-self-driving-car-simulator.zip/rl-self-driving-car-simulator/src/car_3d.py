from ursina import *
import math

class Car3D(Entity):
    def __init__(self, position=(0, 0.5, 0)):
        super().__init__(
            position=position,
        )

        # Create the car body
        body = Entity(parent=self, model='cube', scale=(1.5, 0.5, 1), color=color.blue, shadows=True)
        cabin = Entity(parent=self, model='cube', scale=(0.8, 0.5, 0.8), position=(0, 0.5, 0), color=color.light_gray, shadows=True)

        # Create wheels
        wheel_fr = Entity(parent=self, model='sphere', scale=0.4, position=(0.75, -0.2, 0.4), color=color.black, shadows=True)
        wheel_fl = Entity(parent=self, model='sphere', scale=0.4, position=(-0.75, -0.2, 0.4), color=color.black, shadows=True)
        wheel_br = Entity(parent=self, model='sphere', scale=0.4, position=(0.75, -0.2, -0.4), color=color.black, shadows=True)
        wheel_bl = Entity(parent=self, model='sphere', scale=0.4, position=(-0.75, -0.2, -0.4), color=color.black, shadows=True)

        self.collider = 'box'
        self.scale = (1.5, 1, 1)

        self.speed = 5  # Base forward speed
        self.max_speed = 15
        self.acceleration = 0.2
        self.deceleration = 0.3
        self.turn_speed = 100

        # Lane switching
        self.target_x = self.x
        self.lane_switching_speed = 5  # units per second

        # 3D Sensors
        self.sensor_angles = [-90, -45, 0, 45, 90]
        self.sensor_distances = [0] * len(self.sensor_angles)
        self.max_sensor_distance = 50

    def accelerate(self):
        self.speed += self.acceleration
        if self.speed > self.max_speed:
            self.speed = self.max_speed

    def decelerate(self):
        self.speed -= self.acceleration
        if self.speed < 0:
            self.speed = 0

    def turn_left(self):
        self.rotation_y -= self.turn_speed * time.dt

    def turn_right(self):
        self.rotation_y += self.turn_speed * time.dt

    def update(self):
        # User control
        if held_keys['w']:
            self.accelerate()
        if held_keys['s']:
            self.decelerate()
        if held_keys['a']:
            # Switch lane left
            if hasattr(self.parent, 'road'):
                lane_positions = self.parent.road.lane_positions
                current_x = self.x
                lane_index = None
                for i, lane_x in enumerate(lane_positions):
                    if abs(current_x - lane_x) < 1:
                        lane_index = i
                        break
                if lane_index is not None and lane_index > 0:
                    self.target_x = lane_positions[lane_index - 1]
        if held_keys['d']:
            # Switch lane right
            if hasattr(self.parent, 'road'):
                lane_positions = self.parent.road.lane_positions
                current_x = self.x
                lane_index = None
                for i, lane_x in enumerate(lane_positions):
                    if abs(current_x - lane_x) < 1:
                        lane_index = i
                        break
                if lane_index is not None and lane_index < len(lane_positions) - 1:
                    self.target_x = lane_positions[lane_index + 1]

        # Smooth lane switching towards target_x
        if abs(self.x - self.target_x) > 0.1:
            direction = 1 if self.target_x > self.x else -1
            self.x += direction * self.lane_switching_speed * time.dt
            # Clamp to target_x to avoid overshoot
            if (direction == 1 and self.x > self.target_x) or (direction == -1 and self.x < self.target_x):
                self.x = self.target_x

        self.position += self.forward * self.speed * time.dt
        self.speed = max(0, min(self.max_speed, self.speed))
        self.update_sensors()

        # Collision detection with obstacles
        for obstacle in self.parent.road.obstacles if hasattr(self.parent, 'road') else []:
            if self.intersects(obstacle).hit:
                self.speed = 0
                print("Collision detected!")
                break

    def update_sensors(self):
        for i, angle in enumerate(self.sensor_angles):
            direction = self.forward.x * math.cos(math.radians(angle)) - self.forward.z * math.sin(math.radians(angle)), \
                        0, \
                        self.forward.x * math.sin(math.radians(angle)) + self.forward.z * math.cos(math.radians(angle))
            hit_info = raycast(self.position, direction, distance=self.max_sensor_distance, ignore=[self])
            if hit_info.hit:
                self.sensor_distances[i] = hit_info.distance
            else:
                self.sensor_distances[i] = self.max_sensor_distance
