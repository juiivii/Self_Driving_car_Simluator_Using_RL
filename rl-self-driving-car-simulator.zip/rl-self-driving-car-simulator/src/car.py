import pygame
import math
from sensors import cast_ray

class Car:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.angle = 90  # Facing upward initially (along the road)
        self.speed = 0
        self.max_speed = 2  # Reduced max speed for slower movement
        self.acceleration = 0.05  # Reduced acceleration for smoother speed increase
        self.deceleration = 0.1
        self.turn_speed = 3  # degrees per frame
        self.length = 40
        self.width = 20

        # Target lane position for smooth lane switching
        self.target_x = x
        self.lane_switching_speed = 12  # pixels per frame for lateral movement (significantly increased)

        # Create a surface for the car with enhanced visuals
        self.original_image = pygame.Surface((self.length, self.width), pygame.SRCALPHA)
        # Draw a simple car shape with colors and details
        self.original_image.fill((0, 0, 0, 0))  # Transparent background
        pygame.draw.rect(self.original_image, (255, 0, 0), (0, 0, self.length, self.width))  # Red body
        pygame.draw.rect(self.original_image, (0, 0, 0), (5, 5, self.length - 10, self.width - 10))  # Black inner
        pygame.draw.rect(self.original_image, (255, 0, 0), (10, 10, self.length - 20, self.width - 20))  # Red inner
        self.image = self.original_image
        self.rect = self.image.get_rect(center=(self.x, self.y))

        # Sensors
        self.sensor_angles = [-90, -75, -60, -45, -30, -15, 0, 15, 30, 45, 60, 75, 90]  # degrees relative to car angle
        self.sensor_distances = [0] * len(self.sensor_angles)
        self.max_sensor_distance = 300

    def accelerate(self):
        if self.speed < self.max_speed:
            self.speed += self.acceleration

    def decelerate(self):
        if self.speed > 0:
            self.speed -= self.deceleration
        if self.speed < 0:
            self.speed = 0

    def turn_left(self):
        # Override to switch lane to the left if possible
        if self.speed != 0:
            # Lane switching logic will be handled externally
            pass

    def turn_right(self):
        # Override to switch lane to the right if possible
        if self.speed != 0:
            # Lane switching logic will be handled externally
            pass

    def set_lane_position(self, x):
        # Set the target lane position for smooth transition
        self.target_x = x

    def update(self, track_boundaries=None):
        # Override update to move car forward automatically
        # Fix car y position to center of screen
        self.y = 600 // 2  # Assuming screen height is 600

        # Smoothly move x towards target_x for lane switching
        if abs(self.x - self.target_x) > self.lane_switching_speed:
            if self.x < self.target_x:
                self.x += self.lane_switching_speed
                self.angle = max(60, self.angle - self.turn_speed)  # Turn right while moving right
            else:
                self.x -= self.lane_switching_speed
                self.angle = min(120, self.angle + self.turn_speed)  # Turn left while moving left
        else:
            self.x = self.target_x
            # Gradually straighten the car angle back to 90
            if self.angle < 90:
                self.angle = min(90, self.angle + self.turn_speed)
            elif self.angle > 90:
                self.angle = max(90, self.angle - self.turn_speed)

        # Create a rect for the new position
        new_rect = self.image.get_rect(center=(self.x, self.y))

        # Check collision with track boundaries and obstacles
        if track_boundaries:
            collision = False
            # Extract track boundaries and obstacles separately
            outer_rect = None
            inner_rect = None
            obstacles = []
            for boundary in track_boundaries:
                if isinstance(boundary, pygame.Rect):
                    # Heuristically identify outer and inner rects by size
                    if outer_rect is None or boundary.width > outer_rect.width:
                        outer_rect = boundary
                    elif inner_rect is None or boundary.width < outer_rect.width:
                        inner_rect = boundary
                    else:
                        obstacles.append(boundary)
                elif isinstance(boundary, tuple) and len(boundary) == 4:
                    # For line segments, approximate collision by checking distance to line
                    pass
            # Check if car center is outside outer_rect or inside inner_rect
            if outer_rect and inner_rect:
                if not outer_rect.collidepoint(self.x, self.y) or inner_rect.collidepoint(self.x, self.y):
                    collision = True
            # Check collision with obstacles
            for obstacle in obstacles:
                if new_rect.colliderect(obstacle):
                    print(f"Collision detected with obstacle at {obstacle}")
                    collision = True
                    break
            if collision:
                # Collision detected, stop the car and do not update position
                self.speed = 0
            else:
                self.rect = new_rect
        else:
            self.rect = new_rect

        self.image = pygame.transform.rotate(self.original_image, self.angle)

    def update_sensors(self, track_boundaries):
        for i, sensor_angle in enumerate(self.sensor_angles):
            ray_angle = (self.angle + sensor_angle) % 360
            distance = cast_ray((self.x, self.y), ray_angle, track_boundaries, self.max_sensor_distance)
            self.sensor_distances[i] = distance

    def draw(self, screen):
        screen.blit(self.image, self.rect)
        # Draw sensor rays
        for i, sensor_angle in enumerate(self.sensor_angles):
            ray_angle = (self.angle + sensor_angle) % 360
            rad = math.radians(ray_angle)
            end_x = self.x + self.sensor_distances[i] * math.cos(rad)
            end_y = self.y - self.sensor_distances[i] * math.sin(rad)
            pygame.draw.line(screen, (0, 255, 0), (self.x, self.y), (end_x, end_y), 2)
