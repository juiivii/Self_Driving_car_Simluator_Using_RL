import math
import pygame

def cast_ray(start_pos, angle, track_boundaries, max_distance=200):
    """
    Cast a ray from start_pos at given angle and find the closest intersection with track boundaries.
    track_boundaries: list of pygame.Rect or lines representing walls or obstacles
    Returns distance to the closest wall or max_distance if no intersection.
    """
    x, y = start_pos
    rad = math.radians(angle)
    dx = math.cos(rad)
    dy = -math.sin(rad)

    for distance in range(max_distance):
        test_x = x + dx * distance
        test_y = y + dy * distance
        point = (test_x, test_y)
        # Check collision with boundaries or obstacles
        for boundary in track_boundaries:
            if isinstance(boundary, pygame.Rect):
                if boundary.collidepoint(point):
                    return distance
            elif isinstance(boundary, tuple) and len(boundary) == 4:
                # boundary as line segment (x1, y1, x2, y2)
                if point_on_line_segment(point, boundary):
                    return distance
    return max_distance

def point_on_line_segment(point, line):
    """
    Check if point is close to the line segment within a threshold.
    line: (x1, y1, x2, y2)
    """
    x, y = point
    x1, y1, x2, y2 = line
    # Calculate distance from point to line segment
    line_mag = math.hypot(x2 - x1, y2 - y1)
    if line_mag < 0.000001:
        return False
    u = ((x - x1) * (x2 - x1) + (y - y1) * (y2 - y1)) / (line_mag * line_mag)
    if u < 0 or u > 1:
        return False
    ix = x1 + u * (x2 - x1)
    iy = y1 + u * (y2 - y1)
    dist = math.hypot(x - ix, y - iy)
    threshold = 3  # pixels
    return dist < threshold
